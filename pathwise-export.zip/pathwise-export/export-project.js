const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Create a file mapping of your project structure
const projectFiles = {
  // Root files
  'package.json': require('./package.json'),
  'tsconfig.json': require('./tsconfig.json'),
  'vite.config.ts': fs.readFileSync('./vite.config.ts', 'utf8'),
  'tailwind.config.ts': fs.readFileSync('./tailwind.config.ts', 'utf8'),
  'postcss.config.js': fs.readFileSync('./postcss.config.js', 'utf8'),
  'drizzle.config.ts': fs.readFileSync('./drizzle.config.ts', 'utf8'),
  'components.json': fs.readFileSync('./components.json', 'utf8'),
  
  // Client files
  'client/index.html': fs.readFileSync('./client/index.html', 'utf8'),
  'client/env.d.ts': fs.readFileSync('./client/env.d.ts', 'utf8'),
  'client/src/main.tsx': fs.readFileSync('./client/src/main.tsx', 'utf8'),
  'client/src/App.tsx': fs.readFileSync('./client/src/App.tsx', 'utf8'),
  'client/src/index.css': fs.readFileSync('./client/src/index.css', 'utf8'),
  
  // Components
  'client/src/components/navbar.tsx': fs.readFileSync('./client/src/components/navbar.tsx', 'utf8'),
  'client/src/components/hero-section.tsx': fs.readFileSync('./client/src/components/hero-section.tsx', 'utf8'),
  'client/src/components/features-section.tsx': fs.readFileSync('./client/src/components/features-section.tsx', 'utf8'),
  'client/src/components/how-it-works.tsx': fs.readFileSync('./client/src/components/how-it-works.tsx', 'utf8'),
  'client/src/components/roadmaps-section.tsx': fs.readFileSync('./client/src/components/roadmaps-section.tsx', 'utf8'),
  'client/src/components/signup-form.tsx': fs.readFileSync('./client/src/components/signup-form.tsx', 'utf8'),
  'client/src/components/footer.tsx': fs.readFileSync('./client/src/components/footer.tsx', 'utf8'),
  'client/src/components/chatbot.tsx': fs.readFileSync('./client/src/components/chatbot.tsx', 'utf8'),
  
  // Server files
  'server/index.ts': fs.readFileSync('./server/index.ts', 'utf8'),
  'server/db.ts': fs.readFileSync('./server/db.ts', 'utf8'),
  'server/routes.ts': fs.readFileSync('./server/routes.ts', 'utf8'),
  'server/storage.ts': fs.readFileSync('./server/storage.ts', 'utf8'),
  'server/email.ts': fs.readFileSync('./server/email.ts', 'utf8'),
  'server/vite.ts': fs.readFileSync('./server/vite.ts', 'utf8'),
  
  // Shared files
  'shared/schema.ts': fs.readFileSync('./shared/schema.ts', 'utf8'),
  
  // Setup files
  'README.md': `# Pathwise Career Platform

A comprehensive career guidance platform built with React, TypeScript, and Express.js.

## Features

- Authentic career roadmaps from real professionals
- Realistic salary progression data
- Location-based career intelligence
- Early access signup system
- Modern responsive design

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Vite
- **Backend**: Express.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Components**: Radix UI + shadcn/ui
- **State Management**: TanStack Query
- **Routing**: Wouter
- **Forms**: React Hook Form + Zod validation

## Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- npm or yarn

### Installation

1. Clone the repository
\`\`\`bash
git clone <your-repo-url>
cd pathwise
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
Create a \`.env\` file in the root directory:
\`\`\`
DATABASE_URL=your_postgresql_connection_string
PGHOST=localhost
PGPORT=5432
PGDATABASE=pathwise
PGUSER=your_username
PGPASSWORD=your_password
\`\`\`

4. Set up the database
\`\`\`bash
npm run db:push
\`\`\`

5. Start the development server
\`\`\`bash
npm run dev
\`\`\`

The application will be available at \`http://localhost:5000\`

## Project Structure

\`\`\`
pathwise/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   └── main.tsx        # Application entry point
│   └── index.html          # HTML template
├── server/                 # Backend Express application
│   ├── index.ts            # Server entry point
│   ├── routes.ts           # API routes
│   ├── db.ts               # Database connection
│   ├── storage.ts          # Data access layer
│   └── email.ts            # Email functionality
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Database schema definitions
└── package.json            # Project dependencies
\`\`\`

## Available Scripts

- \`npm run dev\` - Start development server
- \`npm run build\` - Build for production
- \`npm run preview\` - Preview production build
- \`npm run db:push\` - Push database schema changes
- \`npm run db:studio\` - Open Drizzle Studio

## Deployment

### Database Setup

1. Create a PostgreSQL database
2. Update your \`DATABASE_URL\` environment variable
3. Run \`npm run db:push\` to create tables

### Environment Variables

Required environment variables for production:
- \`DATABASE_URL\` - PostgreSQL connection string
- \`SENDGRID_API_KEY\` - For email functionality (optional)
- \`VITE_GA_MEASUREMENT_ID\` - Google Analytics (optional)

### Build and Deploy

1. Build the application:
\`\`\`bash
npm run build
\`\`\`

2. Deploy to your preferred platform (Vercel, Netlify, Railway, etc.)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License.
`,
  '.env.example': `# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/pathwise
PGHOST=localhost
PGPORT=5432
PGDATABASE=pathwise
PGUSER=your_username
PGPASSWORD=your_password

# Optional Services
SENDGRID_API_KEY=your_sendgrid_api_key
VITE_GA_MEASUREMENT_ID=your_google_analytics_id
`,
  '.gitignore': `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Build outputs
dist/
build/

# Environment variables
.env
.env.local
.env.production

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Database
*.db
*.sqlite

# Logs
logs/
*.log

# Runtime
.replit
replit.nix
`
};

console.log('Creating project export...');
console.log('Files prepared for export');