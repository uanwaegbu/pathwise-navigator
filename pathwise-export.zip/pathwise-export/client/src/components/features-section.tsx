import { Users, TrendingUp, MapPin } from "lucide-react";

export default function FeaturesSection() {
  const features = [
    {
      icon: Users,
      title: "Real Stories, Not Generic Advice",
      description: "See actual career journeys from people who started exactly where you are. No more wondering if advice applies to you—these are real progressions with specific timelines and companies.",
      highlight: "From Howard University to Microsoft in 3.5 years",
      gradient: "from-blue-500 to-purple-600"
    },
    {
      icon: TrendingUp,
      title: "Honest Salary Progressions",
      description: "Know what you're actually worth and what growth looks like. See real salary jumps, promotion timelines, and what skills unlock the next level.",
      highlight: "Track realistic 65-85% salary increases over time",
      gradient: "from-green-500 to-emerald-600"
    },
    {
      icon: MapPin,
      title: "Location-Based Career Intelligence", 
      description: "Discover which cities offer the best opportunities for your field. Get insider knowledge on where recent grads are actually landing jobs and building careers.",
      highlight: "Austin tech scene vs LA data roles vs Seattle startups",
      gradient: "from-teal-500 to-cyan-600"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-br from-teal-100 to-green-100 rounded-full opacity-30"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full opacity-40"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-teal-100 to-green-100 rounded-full text-teal-700 font-medium text-sm mb-4">
            What Makes Us Different
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
            Career Guidance That Actually Works
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Stop getting generic advice that doesn't apply to your situation. Get real insights from people who've walked your exact path.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="group bg-gradient-to-br from-slate-50 to-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-slate-100 relative overflow-hidden">
              {/* Gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
              
              {/* Icon */}
              <div className={`bg-gradient-to-br ${feature.gradient} rounded-2xl p-4 w-16 h-16 mb-6 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                <feature.icon className="text-white w-8 h-8" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-teal-700 transition-colors">
                {feature.title}
              </h3>
              
              <p className="text-slate-600 leading-relaxed mb-4">
                {feature.description}
              </p>

              {/* Highlight example */}
              <div className="bg-gradient-to-r from-slate-100 to-slate-50 rounded-xl p-4 border-l-4 border-teal-500">
                <p className="text-sm font-medium text-slate-700 italic">
                  "{feature.highlight}"
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-50 to-green-50 rounded-full text-teal-700 font-medium border border-teal-200">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            Real people, real results, real career growth
          </div>
        </div>
      </div>
    </section>
  );
}