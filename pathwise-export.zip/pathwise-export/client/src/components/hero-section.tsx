import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

export default function HeroSection() {
  const scrollToSignup = () => {
    const element = document.getElementById('signup');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-teal-500 via-teal-600 to-green-500 text-white">
      {/* Enhanced background with animated elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-teal-600/20 to-green-400/20"></div>
        <div className="absolute top-20 left-20 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-emerald-300/20 rounded-full blur-3xl animate-bounce"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-300/15 rounded-full blur-2xl"></div>
        
        {/* Floating elements */}
        <div className="absolute top-32 right-1/4 w-4 h-4 bg-green-300 rounded-full animate-ping"></div>
        <div className="absolute bottom-40 left-1/3 w-3 h-3 bg-teal-300 rounded-full animate-pulse"></div>
        <div className="absolute top-1/3 right-1/3 w-2 h-2 bg-emerald-300 rounded-full animate-bounce"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left animate-slide-up">
            {/* Hero badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white font-medium text-sm mb-6 border border-white/30">
              <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
              Career guidance that actually works
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              You've Got the Degree —<br/>
              <span className="text-green-300 bg-gradient-to-r from-green-300 to-emerald-300 bg-clip-text text-transparent">
                Now Get the Direction
              </span>
            </h1>
            
            <p className="text-xl lg:text-2xl mb-4 text-teal-100 font-medium">
              3 out of 4 young professionals are stuck in career limbo.
            </p>
            
            <p className="text-lg mb-8 text-teal-50 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Whether you're a confused college student, overwhelmed recent grad, or professional questioning your path — you're not alone. Pathwise cuts through the noise with real roadmaps from people who've been exactly where you are.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <Button
                onClick={scrollToSignup}
                className="bg-white text-teal-600 hover:bg-teal-50 px-10 py-4 rounded-full font-bold text-lg transition-all transform hover:scale-105 shadow-xl hover:shadow-2xl"
              >
                Join Early Access
              </Button>
            </div>
            
            {/* Trust indicators */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-6 text-sm text-teal-100">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-300 rounded-full"></div>
                Real career stories
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-300 rounded-full"></div>
                Authentic templates
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-300 rounded-full"></div>
                Proven strategies
              </div>
            </div>
          </div>
          
          <div className="relative animate-fade-in">
            {/* Enhanced image container */}
            <div className="relative group">
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Students collaborating on career planning" 
                className="rounded-3xl shadow-2xl w-full h-auto group-hover:scale-105 transition-transform duration-500" 
              />
              
              {/* Enhanced floating success card */}
              <div className="absolute -bottom-8 -left-8 bg-white rounded-2xl p-6 shadow-2xl animate-bounce-subtle border border-slate-200 max-w-xs">
                <div className="flex items-center">
                  <div className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl p-3 mr-4">
                    <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-slate-800">Career Match</div>
                    <div className="text-green-600 font-bold">Perfect Fit Found</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
