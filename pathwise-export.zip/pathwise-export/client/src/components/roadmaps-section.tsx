import { Button } from "@/components/ui/button";
import { TrendingUp, Clock, MapPin } from "lucide-react";

export default function RoadmapsSection() {
  const roadmaps = [
    {
      name: "Jasmine Williams",
      transition: "Communications → Digital Marketing Manager",
      avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      steps: [
        "Graduated with Communications degree from Howard University",
        "Worked as marketing assistant for 1.5 years while learning",
        "Completed Google Digital Marketing certification",
        "Promoted to marketing coordinator, then manager role",
        "Now: Digital Marketing Manager at Microsoft"
      ],
      duration: "3.5 years",
      increase: "85%",
      company: "Microsoft",
      location: "Seattle, WA",
      gradient: "from-blue-500 to-purple-600"
    },
    {
      name: "Carlos Rodriguez", 
      transition: "Computer Science → Software Engineer",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      steps: [
        "CS graduate from UT Austin",
        "Worked as junior developer for 18 months",
        "Built side projects and contributed to open source", 
        "Completed additional full-stack training",
        "Now: Software Engineer at Shopify"
      ],
      duration: "2.5 years",
      increase: "65%",
      company: "Shopify",
      location: "Austin, TX",
      gradient: "from-green-500 to-emerald-600"
    },
    {
      name: "Zoe Thompson",
      transition: "Biology → Data Analyst", 
      avatar: "https://images.unsplash.com/photo-1488508872907-592763824245?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      steps: [
        "Biology degree from Spelman College",
        "Worked in lab research for 2 years while transitioning",
        "Self-taught Python, SQL, and statistics",
        "Completed data science bootcamp and internship",
        "Now: Data Analyst at Netflix"
      ],
      duration: "3 years",
      increase: "78%",
      company: "Netflix",
      location: "Los Angeles, CA",
      gradient: "from-red-500 to-pink-600"
    }
  ];

  return (
    <section id="roadmaps" className="py-20 bg-gradient-to-b from-slate-50 to-teal-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-32 right-20 w-40 h-40 bg-gradient-to-br from-teal-200 to-green-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-32 left-20 w-32 h-32 bg-gradient-to-br from-green-200 to-emerald-200 rounded-full opacity-30"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full text-emerald-700 font-medium text-sm mb-4">
            Success Stories
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
            Real Roadmaps from Real People
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            See how others with your major successfully transitioned into their dream careers at top companies.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {roadmaps.map((roadmap, index) => (
            <div key={index} className="group bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-slate-100 relative overflow-hidden">
              {/* Card gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${roadmap.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}></div>
              
              {/* Header with enhanced profile */}
              <div className="flex items-center mb-6 relative">
                <div className="relative">
                  <img 
                    src={roadmap.avatar}
                    alt={`${roadmap.name} success story`}
                    className="w-16 h-16 rounded-2xl object-cover ring-4 ring-white shadow-lg group-hover:scale-110 transition-transform duration-300" 
                  />
                  <div className={`absolute -bottom-1 -right-1 w-6 h-6 bg-gradient-to-br ${roadmap.gradient} rounded-full flex items-center justify-center`}>
                    <TrendingUp className="w-3 h-3 text-white" />
                  </div>
                </div>
                <div className="ml-4 flex-1">
                  <div className="font-bold text-slate-900 text-lg group-hover:text-teal-700 transition-colors">{roadmap.name}</div>
                  <div className="text-sm text-slate-600 font-medium">{roadmap.transition}</div>
                  <div className="flex items-center gap-4 mt-1">
                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <MapPin className="w-3 h-3" />
                      {roadmap.location}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-emerald-600 font-medium">
                      <Clock className="w-3 h-3" />
                      {roadmap.duration}
                    </div>
                  </div>
                </div>
              </div>

              {/* Career journey steps */}
              <div className="space-y-4 mb-6">
                {roadmap.steps.map((step, stepIndex) => (
                  <div key={stepIndex} className="flex items-start text-sm group/step">
                    <div className={`flex-shrink-0 w-6 h-6 rounded-full mr-3 mt-0.5 flex items-center justify-center ${
                      stepIndex === roadmap.steps.length - 1 
                        ? `bg-gradient-to-br ${roadmap.gradient} text-white shadow-lg` 
                        : 'bg-slate-200 text-slate-600'
                    }`}>
                      {stepIndex + 1}
                    </div>
                    <span className={`leading-relaxed group-hover/step:text-slate-700 transition-colors ${
                      stepIndex === roadmap.steps.length - 1 ? 'font-semibold text-slate-900' : 'text-slate-600'
                    }`}>
                      {step}
                    </span>
                  </div>
                ))}
              </div>

              {/* Enhanced metrics */}
              <div className="pt-6 border-t border-slate-100">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl">
                    <div className="text-lg font-bold text-emerald-700">+{roadmap.increase}</div>
                    <div className="text-xs text-emerald-600 font-medium">Salary Boost</div>
                  </div>
                  <div className="text-center p-3 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                    <div className="text-lg font-bold text-blue-700">{roadmap.company}</div>
                    <div className="text-xs text-blue-600 font-medium">Current Role</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>


      </div>
    </section>
  );
}
