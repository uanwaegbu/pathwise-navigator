import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export default function CareerClarity() {
  const features = [
    "Personalized career alignment analysis",
    "Skills gap identification and recommendations", 
    "Location-based job market insights"
  ];

  const scrollToSignup = () => {
    const element = document.getElementById('signup');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
              Your <span className="text-teal-600">Career Clarity Score™</span> Awaits
            </h2>
            <p className="text-xl text-slate-600 mb-8">
              Get instant insights into how well your major aligns with your career goals, plus personalized recommendations to bridge any gaps.
            </p>
            
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center">
                  <div className="bg-green-500 rounded-full p-2 mr-4">
                    <Check className="text-white w-4 h-4" />
                  </div>
                  <span className="text-slate-700">{feature}</span>
                </div>
              ))}
            </div>

            <Button 
              onClick={scrollToSignup}
              className="bg-teal-600 text-white hover:bg-teal-700 px-8 py-4 rounded-full font-semibold text-lg"
            >
              Calculate My Score
            </Button>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Career analytics dashboard" 
              className="rounded-2xl shadow-xl w-full h-auto" 
            />
            
            <div className="absolute top-6 left-6 bg-white rounded-xl p-4 shadow-lg max-w-xs">
              <div className="flex items-center mb-3">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="font-semibold text-slate-800">Career Clarity Score</span>
              </div>
              <div className="text-3xl font-bold text-teal-600 mb-1">87%</div>
              <div className="text-sm text-slate-600">Strong alignment with Software Engineering</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
