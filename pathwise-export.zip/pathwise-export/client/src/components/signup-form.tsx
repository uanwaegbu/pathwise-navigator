import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertEarlyAccessSchema } from "@shared/schema";
import type { InsertEarlyAccess } from "@shared/schema";
import { trackEvent } from "@/lib/analytics";

export default function SignupForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<InsertEarlyAccess>({
    resolver: zodResolver(insertEarlyAccessSchema),
    defaultValues: {
      name: "",
      email: "",
      major: "",
      dreamJob: "",
      agreedToUpdates: false,
    },
  });

  const signupMutation = useMutation({
    mutationFn: async (data: InsertEarlyAccess) => {
      const response = await apiRequest("POST", "/api/early-access", data);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Success!",
        description: "You've been added to our early access list. Check your email for next steps!",
      });
      // Track successful signup
      trackEvent('signup_completed', 'early_access', 'signup_form');
      queryClient.invalidateQueries({ queryKey: ["/api/early-access/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/early-access"] });
      form.reset();
    },
    onError: (error: any) => {
      const message = error.message.includes("EMAIL_EXISTS") 
        ? "This email is already registered for early access." 
        : "Something went wrong. Please try again.";
      
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertEarlyAccess) => {
    signupMutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <section id="signup" className="py-20 bg-gradient-to-br from-teal-600 to-green-500 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="bg-white rounded-2xl p-8 shadow-2xl">
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Welcome to Pathwise!</h2>
              <p className="text-xl text-slate-600 mb-6">
                You're officially on our early access list. We'll be in touch soon with your personalized career roadmap and exclusive resources!
              </p>
              <Button 
                onClick={() => setIsSubmitted(false)}
                variant="outline"
                className="border-teal-600 text-teal-600 hover:bg-teal-50"
              >
                Sign Up Another Person
              </Button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="signup" className="py-20 bg-gradient-to-br from-teal-600 to-green-500 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Get Early Access
          </h2>
          <p className="text-xl text-teal-100 max-w-3xl mx-auto">
            Skip the guesswork and generic advice. Get early access to authentic career roadmaps from real professionals, industry-specific templates, and personalized guidance that actually works. Unlike other platforms that give you basic assessments, we connect you with proven paths to success.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-2xl">
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                Full Name
              </Label>
              <Input
                id="name"
                placeholder="Enter your full name"
                {...form.register("name")}
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
              />
              {form.formState.errors.name && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.name.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                Email Address
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                {...form.register("email")}
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
              />
              {form.formState.errors.email && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="major" className="block text-sm font-medium text-slate-700 mb-2">
                Current Major/Field
              </Label>
              <Select onValueChange={(value) => form.setValue("major", value)}>
                <SelectTrigger className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors">
                  <SelectValue placeholder="Select your major" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="computer-science">Computer Science</SelectItem>
                  <SelectItem value="psychology">Psychology</SelectItem>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="engineering">Engineering</SelectItem>
                  <SelectItem value="biology">Biology</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.major && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.major.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="dreamJob" className="block text-sm font-medium text-slate-700 mb-2">
                Dream Job/Career Goal
              </Label>
              <Input
                id="dreamJob"
                placeholder="e.g., UX Designer, Software Engineer"
                {...form.register("dreamJob")}
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
              />
              {form.formState.errors.dreamJob && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.dreamJob.message}</p>
              )}
            </div>
            
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="agreedToUpdates"
                  checked={form.watch("agreedToUpdates")}
                  onCheckedChange={(checked) => form.setValue("agreedToUpdates", !!checked)}
                  className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                />
                <Label htmlFor="agreedToUpdates" className="text-sm text-slate-600">
                  I agree to receive early access updates and career insights from Pathwise
                </Label>
              </div>
              {form.formState.errors.agreedToUpdates && (
                <p className="text-red-500 text-sm mt-1">{form.formState.errors.agreedToUpdates.message}</p>
              )}
            </div>
            
            <div className="md:col-span-2">
              <Button
                type="submit"
                disabled={signupMutation.isPending}
                className="w-full bg-teal-600 text-white hover:bg-teal-700 py-4 rounded-xl font-semibold text-lg transition-colors transform hover:scale-[1.02]"
              >
                {signupMutation.isPending ? "Signing Up..." : "Get My Career Clarity Score™ + Early Access"}
              </Button>
              <div className="text-center mt-4 text-sm text-slate-500">
                No spam. Unsubscribe anytime. Your data is secure.
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
