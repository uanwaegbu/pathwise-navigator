import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-teal-600 flex items-center">
              <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
              </svg>
              Pathwise
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('features')}
              className="text-slate-600 hover:text-teal-600 transition-colors"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('how-it-works')}
              className="text-slate-600 hover:text-teal-600 transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection('roadmaps')}
              className="text-slate-600 hover:text-teal-600 transition-colors"
            >
              Roadmaps
            </button>
            <Button 
              onClick={() => scrollToSection('signup')}
              className="bg-teal-600 text-white hover:bg-teal-700 rounded-full px-6"
            >
              Join Early Access
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-slate-600"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <button 
              onClick={() => scrollToSection('features')}
              className="block w-full text-left px-3 py-2 text-slate-600 hover:text-teal-600 transition-colors"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('how-it-works')}
              className="block w-full text-left px-3 py-2 text-slate-600 hover:text-teal-600 transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection('roadmaps')}
              className="block w-full text-left px-3 py-2 text-slate-600 hover:text-teal-600 transition-colors"
            >
              Roadmaps
            </button>
            <Button 
              onClick={() => scrollToSection('signup')}
              className="w-full bg-teal-600 text-white hover:bg-teal-700 rounded-full mt-4"
            >
              Join Early Access
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
}
