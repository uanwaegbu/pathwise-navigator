import { GraduationCap, Route, Rocket, ArrowDown } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: GraduationCap,
      title: "Share Your Background",
      description: "Tell us about your major, interests, and dream job. Connect with real career stories from people with similar backgrounds.",
      color: "from-teal-500 to-teal-600",
      number: "01"
    },
    {
      icon: Route,
      title: "Get Your Roadmap",
      description: "Access proven career paths and strategies from professionals who successfully transitioned into your target role.",
      color: "from-green-400 to-green-500",
      number: "02"
    },
    {
      icon: Rocket,
      title: "Launch Your Career",
      description: "Follow actionable steps with downloadable templates, networking guidance, and skill development resources.",
      color: "from-teal-600 to-teal-700",
      number: "03"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-b from-slate-50 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-teal-100 rounded-full opacity-40 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-green-100 rounded-full opacity-30 animate-bounce"></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-emerald-100 rounded-full opacity-50"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-teal-100 to-green-100 rounded-full text-teal-700 font-medium text-sm mb-4">
            Simple Process
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
            How Pathwise Works
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            From confusion to career clarity in three simple steps. Connect with real career journeys.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12 relative">
          {/* Connection lines for desktop */}
          <div className="hidden lg:block absolute top-16 left-1/4 right-1/4 h-0.5 bg-gradient-to-r from-teal-200 via-green-200 to-teal-200"></div>
          
          {steps.map((step, index) => (
            <div key={index} className="text-center group relative">
              {/* Step number */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-br from-teal-500 to-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-lg">
                {step.number}
              </div>
              
              {/* Icon container with enhanced animations */}
              <div className={`bg-gradient-to-br ${step.color} rounded-3xl p-8 w-24 h-24 mx-auto mb-6 flex items-center justify-center group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-xl group-hover:shadow-2xl relative overflow-hidden`}>
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
                <step.icon className="text-white w-10 h-10 relative z-10" />
              </div>

              {/* Content with better typography */}
              <h3 className="text-xl font-bold text-slate-900 mb-4 group-hover:text-teal-700 transition-colors">
                {step.title}
              </h3>
              <p className="text-slate-600 leading-relaxed max-w-sm mx-auto">
                {step.description}
              </p>

              {/* Arrow connector for mobile */}
              {index < steps.length - 1 && (
                <div className="lg:hidden flex justify-center mt-8 mb-4">
                  <ArrowDown className="w-6 h-6 text-teal-400 animate-bounce" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Call to action */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-50 to-green-50 rounded-full text-teal-700 font-medium border border-teal-200">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            Ready to start your journey?
          </div>
        </div>
      </div>
    </section>
  );
}
