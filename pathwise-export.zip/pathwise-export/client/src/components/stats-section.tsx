export default function StatsSection() {
  const stats = [
    { value: "70%", label: "Report Career Confidence" },
    { value: "3x", label: "Faster Job Placement" },
    { value: "85%", label: "Land Target Role" },
    { value: "50K+", label: "Active Job Seekers" },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-teal-600 mb-2">
                {stat.value}
              </div>
              <div className="text-slate-600">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
