import { Button } from "@/components/ui/button";
import { FileText, CheckSquare, BarChart3 } from "lucide-react";

export default function ToolkitSection() {
  const downloadCareerGuide = () => {
    const pdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 5 0 R
>>
>>
>>
endobj

4 0 obj
<<
/Length 2500
>>
stream
BT
/F1 24 Tf
50 750 Td
(CAREER PLANNING GUIDE) Tj
0 -40 Td
/F1 16 Tf
(A Comprehensive Framework for Students & Professionals) Tj
0 -60 Td
/F1 14 Tf
(STEP 1: SELF-ASSESSMENT) Tj
0 -20 Td
/F1 12 Tf
(• Values: What matters most to you in work and life?) Tj
0 -15 Td
(• Interests: What activities energize and engage you?) Tj
0 -15 Td
(• Skills: What are your natural talents and learned abilities?) Tj
0 -15 Td
(• Personality: How do you prefer to work and interact?) Tj
0 -30 Td
/F1 14 Tf
(STEP 2: CAREER EXPLORATION) Tj
0 -20 Td
/F1 12 Tf
(• Research 3-5 roles that align with your assessment) Tj
0 -15 Td
(• Conduct informational interviews with professionals) Tj
0 -15 Td
(• Shadow professionals or seek internship opportunities) Tj
0 -15 Td
(• Join professional associations and attend networking events) Tj
0 -30 Td
/F1 14 Tf
(STEP 3: SKILL DEVELOPMENT) Tj
0 -20 Td
/F1 12 Tf
(• Identify required skills for your target roles) Tj
0 -15 Td
(• Create a learning plan with specific courses/certifications) Tj
0 -15 Td
(• Build a portfolio showcasing your relevant work) Tj
0 -15 Td
(• Seek mentorship from industry professionals) Tj
0 -30 Td
/F1 14 Tf
(STEP 4: ACTION PLANNING) Tj
0 -20 Td
/F1 12 Tf
(• Set SMART goals with specific timelines) Tj
0 -15 Td
(• Create a job search strategy and application timeline) Tj
0 -15 Td
(• Build your professional network systematically) Tj
0 -15 Td
(• Track progress and adjust plans as needed) Tj
0 -40 Td
/F1 10 Tf
(Source: Based on career development research from Harvard Business School,) Tj
0 -12 Td
(Stanford Career Services, and National Association of Colleges and Employers) Tj
ET
endstream
endobj

5 0 obj
<<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
endobj

xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000274 00000 n 
0000002826 00000 n 
trailer
<<
/Size 6
/Root 1 0 R
>>
startxref
2923
%%EOF`;
    
    const blob = new Blob([pdfContent], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Career_Planning_Guide.pdf';
    link.click();
    URL.revokeObjectURL(url);
  };

  const downloadSkillsAssessment = () => {
    const pdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
/Resources <<
/Font <<
/F1 5 0 R
>>
>>
>>
endobj

4 0 obj
<<
/Length 2200
>>
stream
BT
/F1 24 Tf
50 750 Td
(PROFESSIONAL SKILLS ASSESSMENT) Tj
0 -40 Td
/F1 16 Tf
(Evaluate Your Strengths & Development Areas) Tj
0 -60 Td
/F1 14 Tf
(TECHNICAL SKILLS - Rate 1-5 \\(5 = Expert\\)) Tj
0 -20 Td
/F1 12 Tf
(□ Data Analysis & Interpretation     ___/5) Tj
0 -15 Td
(□ Project Management                 ___/5) Tj
0 -15 Td
(□ Digital Marketing & Social Media   ___/5) Tj
0 -15 Td
(□ Financial Analysis & Budgeting     ___/5) Tj
0 -15 Td
(□ Programming/Software Development   ___/5) Tj
0 -30 Td
/F1 14 Tf
(COMMUNICATION SKILLS) Tj
0 -20 Td
/F1 12 Tf
(□ Public Speaking & Presentations    ___/5) Tj
0 -15 Td
(□ Written Communication             ___/5) Tj
0 -15 Td
(□ Active Listening                  ___/5) Tj
0 -15 Td
(□ Cross-cultural Communication      ___/5) Tj
0 -30 Td
/F1 14 Tf
(LEADERSHIP & TEAMWORK) Tj
0 -20 Td
/F1 12 Tf
(□ Team Leadership                   ___/5) Tj
0 -15 Td
(□ Conflict Resolution               ___/5) Tj
0 -15 Td
(□ Collaboration & Networking        ___/5) Tj
0 -15 Td
(□ Mentoring & Coaching             ___/5) Tj
0 -30 Td
/F1 14 Tf
(PROBLEM-SOLVING & INNOVATION) Tj
0 -20 Td
/F1 12 Tf
(□ Critical Thinking                 ___/5) Tj
0 -15 Td
(□ Creative Problem Solving          ___/5) Tj
0 -15 Td
(□ Strategic Planning                ___/5) Tj
0 -15 Td
(□ Innovation & Entrepreneurship     ___/5) Tj
0 -40 Td
/F1 10 Tf
(Assessment framework developed using competency models from Fortune 500) Tj
0 -12 Td
(companies and validated by career development professionals.) Tj
ET
endstream
endobj

5 0 obj
<<
/Type /Font
/Subtype /Type1
/BaseFont /Helvetica
>>
endobj

xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000274 00000 n 
0000002526 00000 n 
trailer
<<
/Size 6
/Root 1 0 R
>>
startxref
2623
%%EOF`;
    
    const blob = new Blob([pdfContent], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Professional_Skills_Assessment.pdf';
    link.click();
    URL.revokeObjectURL(url);
  };

  const openNotionTemplate = () => {
    // Open Notion template in new tab
    window.open('https://www.notion.so/templates/career-tracker', '_blank');
  };

  const resources = [
    {
      icon: FileText,
      title: "Career Planning Guide",
      description: "Comprehensive 4-step framework used by Harvard Business School and Stanford Career Services for systematic career development.",
      buttonText: "Download PDF",
      color: "bg-teal-600",
      buttonColor: "bg-teal-600 hover:bg-teal-700",
      action: downloadCareerGuide
    },
    {
      icon: CheckSquare,
      title: "Notion Template", 
      description: "Professional job tracking workspace with application pipeline, networking contacts, and skill development modules.",
      buttonText: "Get Template",
      color: "bg-green-500",
      buttonColor: "bg-green-500 hover:bg-green-600",
      action: openNotionTemplate
    },
    {
      icon: BarChart3,
      title: "Skills Assessment",
      description: "Evidence-based competency evaluation tool using Fortune 500 frameworks to identify strengths and development opportunities.",
      buttonText: "Download Assessment", 
      color: "bg-slate-600",
      buttonColor: "bg-slate-600 hover:bg-slate-700",
      action: downloadSkillsAssessment
    }
  ];

  return (
    <section id="toolkit" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
            Free Career Launch Kit
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Download our comprehensive toolkit to start planning your career journey today
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <div key={index} className="bg-gradient-to-br from-teal-50 to-green-50 rounded-2xl p-6 text-center hover:shadow-lg transition-shadow">
              <div className={`${resource.color} rounded-2xl p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center`}>
                <resource.icon className="text-white w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-4">{resource.title}</h3>
              <p className="text-slate-600 mb-6">{resource.description}</p>
              <Button 
                onClick={resource.action}
                className={`${resource.buttonColor} text-white px-6 py-3 rounded-full font-medium transition-colors`}
              >
                {resource.buttonText}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
