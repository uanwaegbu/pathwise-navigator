import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";
import { trackEvent } from "@/lib/analytics";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi! I'm here to help with your career questions. I can provide guidance on career paths, education choices, and job market insights. What would you like to know?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getCareerResponse = (question: string): string => {
    const lowerQuestion = question.toLowerCase();

    // Pathwise-specific questions
    if (lowerQuestion.includes("pathwise") || lowerQuestion.includes("clarity score") || lowerQuestion.includes("career clarity")) {
      return "Pathwise's Career Clarity Score™ analyzes your major, interests, and career goals against our database of 10,000+ successful career transitions. It gives you a personalized alignment percentage and specific recommendations. Our algorithm considers factors like skill transferability, market demand, and salary potential to help you make data-driven career decisions.";
    }

    // Career transition and major-specific advice
    if (lowerQuestion.includes("psychology") && (lowerQuestion.includes("career") || lowerQuestion.includes("job"))) {
      return "Psychology majors have incredible versatility! Top career paths include: UX Research (leveraging human behavior insights), Data Analytics (understanding consumer psychology), HR/People Operations, Content Strategy, Market Research, and Counseling. The analytical and research skills from psychology translate perfectly to tech roles. Sarah from our roadmaps went from Psychology to Senior UX Designer at Spotify in 18 months.";
    }

    if (lowerQuestion.includes("business") && (lowerQuestion.includes("career") || lowerQuestion.includes("job"))) {
      return "Business majors are positioned for diverse opportunities! High-growth paths include: Product Management (understanding market needs), Business Analytics, Sales Development, Marketing Strategy, Operations, and Consulting. The strategic thinking and communication skills are highly valued. Marcus from our roadmaps transitioned from Business to Senior PM at Airbnb in 2 years with an 89% salary increase.";
    }

    if (lowerQuestion.includes("english") && (lowerQuestion.includes("career") || lowerQuestion.includes("job"))) {
      return "English majors possess powerful communication skills that are in high demand! Emerging career paths include: Content Strategy, Technical Writing, UX Writing, Digital Marketing, Social Media Strategy, Grant Writing, and Brand Storytelling. The writing and critical thinking skills translate beautifully to tech and business roles. Priya from our roadmaps went from English to Head of Content at Notion with a 203% salary increase.";
    }

    // Advanced career guidance
    if (lowerQuestion.includes("career change") || lowerQuestion.includes("switch careers")) {
      return "Career transitions are more common than ever - the average person changes careers 5-7 times! Successful transitions follow our proven framework: 1) Identify transferable skills, 2) Research target role requirements, 3) Bridge skill gaps through courses/projects, 4) Build a portfolio showcasing relevant work, 5) Network with professionals in your target field. Our roadmaps show exact steps others took from your background.";
    }

    // Industry-specific salary and growth insights
    if (lowerQuestion.includes("salary") || lowerQuestion.includes("pay") || lowerQuestion.includes("compensation")) {
      return "Compensation varies significantly by role, location, and experience. Current market data shows: Software Engineering ($85k-250k+), Product Management ($90k-200k+), UX Design ($70k-160k+), Data Analytics ($65k-140k+), Marketing ($50k-130k+). Geographic multipliers: SF Bay Area (1.6x), NYC (1.4x), Austin (1.2x), Remote (0.9-1.1x). Negotiate based on value delivered, not just market rates.";
    }

    // Skills and learning pathways
    if (lowerQuestion.includes("skill") || lowerQuestion.includes("learn") || lowerQuestion.includes("course")) {
      return "Focus on skills with strong ROI and market demand. High-impact technical skills: Python/SQL (data roles), Figma/Design thinking (UX roles), Google Analytics/Marketing tools (marketing roles). Essential soft skills: Data interpretation, stakeholder communication, project management. Our Career Launch Kit includes curated learning paths for each major. What specific role are you targeting?";
    }

    // Job market and hiring trends
    if (lowerQuestion.includes("job market") || lowerQuestion.includes("hiring") || lowerQuestion.includes("trends")) {
      return "The job market is evolving rapidly. Key trends: Remote-first companies expanding talent pools, skills-based hiring over degree requirements, AI augmenting (not replacing) most roles, and emphasis on adaptability. Growth areas include: AI/ML, cybersecurity, healthcare tech, and sustainability. Companies value problem-solving ability and learning agility over specific technical knowledge.";
    }

    // Networking and professional development
    if (lowerQuestion.includes("network") || lowerQuestion.includes("linkedin") || lowerQuestion.includes("connect")) {
      return "Strategic networking accelerates career growth. Effective approaches: 1) Informational interviews (15-20 min conversations), 2) Industry communities (Slack groups, Discord servers), 3) Content creation (share insights on LinkedIn), 4) Alumni networks, 5) Professional events. Focus on giving value first - share resources, make introductions, offer assistance. Quality relationships beat quantity every time.";
    }

    // Interview and application guidance
    if (lowerQuestion.includes("interview") || lowerQuestion.includes("resume") || lowerQuestion.includes("application")) {
      return "Stand out with data-driven applications. Resume optimization: Use action verbs + quantified results (e.g., 'Increased engagement by 40%'). Interview preparation: Master the STAR method (Situation, Task, Action, Result) for behavioral questions. Research the company's challenges and propose solutions. Follow up within 24 hours with specific next steps. Our Career Launch Kit includes proven templates.";
    }

    // Feeling lost or uncertain
    if (lowerQuestion.includes("lost") || lowerQuestion.includes("confused") || lowerQuestion.includes("uncertain") || lowerQuestion.includes("stuck")) {
      return "You're experiencing what 52% of graduates feel - this is completely normal and solvable! Start with self-assessment: What activities energize you? What problems do you enjoy solving? What impact do you want to make? Then explore our roadmaps to see how others with similar backgrounds found their path. Small, consistent actions build momentum. Your degree got you this far - let's help you go further.";
    }

    // Remote work and future of work
    if (lowerQuestion.includes("remote") || lowerQuestion.includes("work from home") || lowerQuestion.includes("hybrid")) {
      return "Remote work is now standard for many roles. Remote-friendly careers include: Software Development, Product Management, Digital Marketing, Content Creation, Customer Success, and Consulting. Key remote skills: Asynchronous communication, self-management, digital collaboration tools. Build these skills through online projects and virtual team experiences. Many of our roadmap professionals work remotely.";
    }

    // Entrepreneurship and side projects
    if (lowerQuestion.includes("startup") || lowerQuestion.includes("entrepreneur") || lowerQuestion.includes("side project")) {
      return "Entrepreneurial skills are valuable even in traditional roles. Start small: Solve a problem you personally face, validate demand before building, leverage your existing network, and focus on generating revenue quickly. Many successful entrepreneurs started as employees who understood industry problems deeply. Consider intrapreneurship opportunities within larger companies first.";
    }

    // Default sophisticated response
    return "That's a thoughtful question! Career planning requires understanding both market dynamics and personal fit. I'd recommend taking our Career Clarity Score™ to get personalized insights based on your specific background and goals. You can also explore our roadmaps database to see detailed career journeys from professionals who started with similar majors and interests. What specific aspect of your career planning feels most challenging right now?";
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Track chatbot usage
    trackEvent('chatbot_message_sent', 'engagement', 'career_guidance');

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getCareerResponse(inputValue),
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // 1-2 second delay
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <Button
          onClick={() => {
            setIsOpen(true);
            trackEvent('chatbot_opened', 'engagement', 'career_guidance');
          }}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-teal-600 hover:bg-teal-700 shadow-lg z-50 transition-all hover:scale-110"
        >
          <MessageCircle className="w-6 h-6 text-white" />
        </Button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-96 h-[500px] shadow-2xl z-50 flex flex-col">
          <CardHeader className="bg-teal-600 text-white rounded-t-lg flex flex-row items-center justify-between p-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Bot className="w-5 h-5" />
              Career Assistant
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-teal-700 h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>

          <CardContent className="flex-1 flex flex-col p-0">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.isBot
                        ? 'bg-slate-100 text-slate-800'
                        : 'bg-teal-600 text-white'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      {message.isBot && <Bot className="w-4 h-4 mt-0.5 text-teal-600" />}
                      <div className="text-sm leading-relaxed">{message.text}</div>
                      {!message.isBot && <User className="w-4 h-4 mt-0.5" />}
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-slate-100 text-slate-800 p-3 rounded-lg max-w-[80%]">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-teal-600" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="border-t p-4">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about careers, jobs, skills..."
                  className="flex-1"
                  disabled={isTyping}
                />
                <Button
                  onClick={handleSend}
                  disabled={!inputValue.trim() || isTyping}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-slate-500 mt-2 text-center">
                Get personalized advice with our Early Access program
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}