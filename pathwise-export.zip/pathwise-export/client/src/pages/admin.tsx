import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Mail, User, GraduationCap, Target } from "lucide-react";
import { format } from "date-fns";

interface EarlyAccessSignup {
  id: number;
  name: string;
  email: string;
  major: string;
  dreamJob: string;
  agreedToUpdates: boolean;
  createdAt: string;
}

interface StatsData {
  totalSignups: number;
  recentSignups: number;
}

export default function Admin() {
  const { data: signups, isLoading: signupsLoading } = useQuery<EarlyAccessSignup[]>({
    queryKey: ["/api/early-access"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<StatsData>({
    queryKey: ["/api/early-access/stats"],
  });

  if (signupsLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  const majorCounts = signups?.reduce((acc, signup) => {
    acc[signup.major] = (acc[signup.major] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const topMajors = Object.entries(majorCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-teal-600 flex items-center">
              <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
              </svg>
              Pathwise Admin
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Signups</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalSignups || 0}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last 24 Hours</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.recentSignups || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Agreed to Updates</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {signups?.filter(s => s.agreedToUpdates).length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Top Major</CardTitle>
              <GraduationCap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold capitalize">
                {topMajors[0]?.[0] || "N/A"}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Signups */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Signups</CardTitle>
                <CardDescription>Latest early access registrations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {signups?.slice(0, 10).map((signup) => (
                    <div key={signup.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-medium">{signup.name}</h3>
                          {signup.agreedToUpdates && (
                            <Badge variant="secondary" className="text-xs">
                              <Mail className="w-3 h-3 mr-1" />
                              Updates
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-slate-600 space-y-1">
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            {signup.email}
                          </div>
                          <div className="flex items-center gap-2">
                            <GraduationCap className="w-4 h-4" />
                            {signup.major}
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            {signup.dreamJob}
                          </div>
                        </div>
                      </div>
                      <div className="text-right text-sm text-slate-500">
                        {format(new Date(signup.createdAt), 'MMM d, yyyy')}
                        <br />
                        {format(new Date(signup.createdAt), 'h:mm a')}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Major Distribution */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Popular Majors</CardTitle>
                <CardDescription>Distribution by field of study</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topMajors.map(([major, count]) => (
                    <div key={major} className="flex items-center justify-between">
                      <span className="text-sm font-medium capitalize">{major}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-slate-200 rounded-full h-2">
                          <div
                            className="bg-teal-600 h-2 rounded-full"
                            style={{
                              width: `${(count / (stats?.totalSignups || 1)) * 100}%`
                            }}
                          />
                        </div>
                        <span className="text-sm text-slate-600 w-8">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}