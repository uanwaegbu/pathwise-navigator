import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Book, MessageCircle, Users, Rocket } from "lucide-react";
import { useState } from "react";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    {
      icon: Rocket,
      title: "Getting Started",
      description: "Learn the basics of Pathwise",
      articles: [
        "How to sign up for early access",
        "Understanding your Career Clarity Score™",
        "Navigating the roadmaps database",
        "Setting up your profile"
      ]
    },
    {
      icon: Book,
      title: "Career Guidance",
      description: "Expert advice for your journey",
      articles: [
        "How to change careers successfully",
        "Building transferable skills",
        "Networking strategies that work",
        "Interview preparation guide"
      ]
    },
    {
      icon: Users,
      title: "Community",
      description: "Connect with other students",
      articles: [
        "Joining study groups",
        "Finding mentors",
        "Sharing your success story",
        "Community guidelines"
      ]
    },
    {
      icon: MessageCircle,
      title: "Technical Support",
      description: "Get help with the platform",
      articles: [
        "Troubleshooting login issues",
        "Updating your information",
        "Privacy settings",
        "Account deletion"
      ]
    }
  ];

  const popularArticles = [
    "What is the Career Clarity Score™?",
    "How do I interpret my roadmap results?",
    "Can I change my major selection?",
    "How often should I update my goals?",
    "What if I don't see my dream job listed?"
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Help Center</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Find answers to your questions and get the most out of Pathwise
          </p>
        </div>

        {/* Search */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <Input
              placeholder="Search for help articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 py-4 text-lg"
            />
            <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-teal-600 hover:bg-teal-700">
              Search
            </Button>
          </div>
        </div>

        {/* Popular Articles */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Popular Articles</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {popularArticles.map((article, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <p className="text-slate-700">{article}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div className="grid md:grid-cols-2 gap-8">
          {categories.map((category, index) => (
            <Card key={index} className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="bg-teal-100 p-2 rounded-lg">
                    <category.icon className="w-6 h-6 text-teal-600" />
                  </div>
                  {category.title}
                </CardTitle>
                <CardDescription>{category.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {category.articles.map((article, articleIndex) => (
                    <li key={articleIndex}>
                      <a href="#" className="text-slate-600 hover:text-teal-600 transition-colors">
                        {article}
                      </a>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Support */}
        <div className="mt-16 text-center">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Still need help?</h3>
              <p className="text-slate-600 mb-6">
                Can't find what you're looking for? Our support team is here to help.
              </p>
              <Button className="bg-teal-600 hover:bg-teal-700 px-8 py-3">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}