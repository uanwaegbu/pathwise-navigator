import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Privacy Policy</h1>
          <p className="text-slate-600 mb-8">Last updated: January 30, 2025</p>

          <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">1. Information We Collect</h2>
            <p className="text-slate-700 mb-4">
              We collect information you provide directly to us, such as when you create an account, sign up for early access, or contact us for support.
            </p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Personal information (name, email address)</li>
              <li>Educational information (major, university)</li>
              <li>Career preferences and goals</li>
              <li>Communication preferences</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">2. How We Use Your Information</h2>
            <p className="text-slate-700 mb-4">We use the information we collect to:</p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Provide and improve our career guidance services</li>
              <li>Generate your Career Clarity Score™</li>
              <li>Send you relevant career insights and updates</li>
              <li>Respond to your questions and provide customer support</li>
              <li>Analyze usage patterns to enhance our platform</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">3. Information Sharing</h2>
            <p className="text-slate-700 mb-4">
              We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy.
            </p>
            <p className="text-slate-700 mb-6">
              We may share aggregated, non-personally identifiable information for research and analytics purposes.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">4. Data Security</h2>
            <p className="text-slate-700 mb-6">
              We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">5. Your Rights</h2>
            <p className="text-slate-700 mb-4">You have the right to:</p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Access your personal information</li>
              <li>Correct inaccurate information</li>
              <li>Delete your account and associated data</li>
              <li>Opt out of marketing communications</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">6. Cookies and Tracking</h2>
            <p className="text-slate-700 mb-6">
              We use cookies and similar technologies to improve your experience on our platform. You can control cookie settings through your browser preferences.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">7. Changes to This Policy</h2>
            <p className="text-slate-700 mb-6">
              We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">8. Contact Us</h2>
            <p className="text-slate-700 mb-6">
              If you have any questions about this privacy policy, please contact us at privacy@pathwise.com or through our contact form.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}