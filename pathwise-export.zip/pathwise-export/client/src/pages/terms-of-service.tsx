import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Terms of Service</h1>
          <p className="text-slate-600 mb-8">Last updated: January 30, 2025</p>

          <div className="prose prose-slate max-w-none">
            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">1. Acceptance of Terms</h2>
            <p className="text-slate-700 mb-6">
              By accessing and using Pathwise, you accept and agree to be bound by the terms and provision of this agreement.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">2. Description of Service</h2>
            <p className="text-slate-700 mb-4">
              Pathwise provides career guidance and educational resources to help students and early-career professionals make informed career decisions.
            </p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Career Clarity Score™ assessments</li>
              <li>Career roadmaps and success stories</li>
              <li>Educational resources and toolkits</li>
              <li>Career guidance and support</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">3. User Responsibilities</h2>
            <p className="text-slate-700 mb-4">You agree to:</p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your account credentials</li>
              <li>Use the service only for lawful purposes</li>
              <li>Respect other users and their privacy</li>
              <li>Not attempt to gain unauthorized access to our systems</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">4. Intellectual Property</h2>
            <p className="text-slate-700 mb-6">
              All content, features, and functionality of Pathwise are owned by us and are protected by intellectual property laws. You may not reproduce, distribute, or create derivative works without our express written permission.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">5. Privacy and Data Protection</h2>
            <p className="text-slate-700 mb-6">
              Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and protect your information.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">6. Disclaimers</h2>
            <p className="text-slate-700 mb-4">
              While we strive to provide accurate and helpful career guidance:
            </p>
            <ul className="list-disc pl-6 text-slate-700 mb-6">
              <li>Career advice is for informational purposes only</li>
              <li>We do not guarantee specific career outcomes</li>
              <li>Individual results may vary based on personal circumstances</li>
              <li>You should conduct your own research and consider multiple sources</li>
            </ul>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">7. Limitation of Liability</h2>
            <p className="text-slate-700 mb-6">
              To the maximum extent permitted by law, Pathwise shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of our service.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">8. Account Termination</h2>
            <p className="text-slate-700 mb-6">
              We reserve the right to suspend or terminate your account if you violate these terms. You may also delete your account at any time through your account settings.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">9. Changes to Terms</h2>
            <p className="text-slate-700 mb-6">
              We may modify these terms at any time. We will notify users of significant changes via email or through our platform. Continued use of the service constitutes acceptance of the modified terms.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">10. Governing Law</h2>
            <p className="text-slate-700 mb-6">
              These terms are governed by the laws of the State of California, United States, without regard to conflict of law principles.
            </p>

            <h2 className="text-2xl font-semibold text-slate-900 mt-8 mb-4">11. Contact Information</h2>
            <p className="text-slate-700 mb-6">
              If you have questions about these terms, please contact us at legal@pathwise.com or through our contact form.
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}