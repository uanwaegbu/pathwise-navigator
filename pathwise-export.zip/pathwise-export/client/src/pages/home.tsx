import Navbar from "@/components/navbar";
import HeroSection from "@/components/hero-section";
import FeaturesSection from "@/components/features-section";
import HowItWorks from "@/components/how-it-works";
import RoadmapsSection from "@/components/roadmaps-section";
import SignupForm from "@/components/signup-form";
import Footer from "@/components/footer";
import Chatbot from "@/components/chatbot";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-teal-50">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <HowItWorks />
      <RoadmapsSection />
      <SignupForm />
      <Footer />
      <Chatbot />
    </div>
  );
}
