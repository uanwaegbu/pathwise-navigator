import { MailService } from '@sendgrid/mail';

let mailService: MailService | null = null;

// Initialize SendGrid if API key is available
if (process.env.SENDGRID_API_KEY) {
  mailService = new MailService();
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!mailService) {
    console.warn('SendGrid not configured - email notification skipped');
    return false;
  }

  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendWelcomeEmail(userEmail: string, userName: string): Promise<boolean> {
  const emailContent = {
    to: userEmail,
    from: 'hello@pathwise.com', // You'll need to verify this domain with SendGrid
    subject: '🎉 You\'re In! Your Career Journey Starts Now',
    text: `Hi ${userName},

🎉 Welcome to Pathwise Early Access!

You just took the most important step in your career journey. While 52% of graduates feel lost, you're now part of an exclusive community that's getting ahead of the curve.

🚀 What happens next?

WEEK 1: Your Career Clarity Score™
We'll analyze your background and send you a personalized career alignment score with specific insights about your strengths and opportunities.

WEEK 2: Your Custom Roadmap
Get access to real career paths from professionals who started exactly where you are - same major, similar goals, proven success.

WEEK 3: Your Action Plan
Receive your personalized Career Launch Kit with templates, guides, and next steps tailored to your dream job.

💡 Pro Tip: Check out our new AI Career Assistant on the website for instant answers to your career questions!

🎁 Exclusive Early Access Perks:
✓ Free Career Launch Kit (Value: $97)
✓ First access to our roadmap database
✓ Priority career coaching spots
✓ Exclusive community of ambitious students

Ready to turn your degree into your dream career?

Let's go further together,
The Pathwise Team

P.S. Reply to this email if you have any urgent career questions - we read every message!`,
    html: `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Welcome to Pathwise!</title>
    </head>
    <body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
      <div style="max-width: 600px; margin: 0 auto; background-color: white;">
        
        <!-- Header with animated gradient -->
        <div style="background: linear-gradient(135deg, #0891b2 0%, #059669 50%, #0891b2 100%); background-size: 200% 200%; padding: 50px 40px; text-align: center; position: relative; overflow: hidden;">
          <div style="position: absolute; top: -50px; left: -50px; width: 100px; height: 100px; background: rgba(255,255,255,0.1); border-radius: 50%; animation: float 6s ease-in-out infinite;"></div>
          <div style="position: absolute; bottom: -30px; right: -30px; width: 60px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 50%; animation: float 4s ease-in-out infinite reverse;"></div>
          
          <div style="font-size: 48px; margin-bottom: 10px;">🎉</div>
          <h1 style="color: white; margin: 0; font-size: 32px; font-weight: bold; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">You're In!</h1>
          <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 18px;">Your career journey starts now</p>
        </div>
        
        <!-- Main content -->
        <div style="padding: 40px;">
          <p style="font-size: 20px; color: #334155; margin: 0 0 20px 0;">Hi ${userName},</p>
          
          <div style="background: linear-gradient(135deg, #f0f9ff 0%, #ecfdf5 100%); padding: 25px; border-radius: 16px; margin: 30px 0; border: 1px solid #e0f2fe;">
            <p style="color: #0f172a; line-height: 1.7; margin: 0; font-size: 16px;">
              <strong>You just took the most important step in your career journey.</strong> While 52% of graduates feel lost, you're now part of an exclusive community that's getting ahead of the curve.
            </p>
          </div>
          
          <!-- Timeline -->
          <div style="margin: 40px 0;">
            <h3 style="color: #0891b2; margin: 0 0 30px 0; font-size: 24px; display: flex; align-items: center;">
              <span style="background: #0891b2; color: white; border-radius: 50%; width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 16px;">🚀</span>
              What happens next?
            </h3>
            
            <!-- Week 1 -->
            <div style="display: flex; margin-bottom: 25px; align-items: flex-start;">
              <div style="background: #0891b2; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; margin-right: 20px; font-weight: bold; flex-shrink: 0;">1</div>
              <div>
                <h4 style="margin: 0 0 8px 0; color: #1e293b; font-size: 18px;">Your Career Clarity Score™</h4>
                <p style="margin: 0; color: #64748b; line-height: 1.6;">We'll analyze your background and send you a personalized career alignment score with specific insights.</p>
                <div style="background: #0891b2; color: white; display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; margin-top: 8px; font-weight: 500;">WEEK 1</div>
              </div>
            </div>
            
            <!-- Week 2 -->
            <div style="display: flex; margin-bottom: 25px; align-items: flex-start;">
              <div style="background: #059669; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; margin-right: 20px; font-weight: bold; flex-shrink: 0;">2</div>
              <div>
                <h4 style="margin: 0 0 8px 0; color: #1e293b; font-size: 18px;">Your Custom Roadmap</h4>
                <p style="margin: 0; color: #64748b; line-height: 1.6;">Real career paths from professionals who started exactly where you are - same major, proven success.</p>
                <div style="background: #059669; color: white; display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; margin-top: 8px; font-weight: 500;">WEEK 2</div>
              </div>
            </div>
            
            <!-- Week 3 -->
            <div style="display: flex; margin-bottom: 25px; align-items: flex-start;">
              <div style="background: #7c3aed; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; margin-right: 20px; font-weight: bold; flex-shrink: 0;">3</div>
              <div>
                <h4 style="margin: 0 0 8px 0; color: #1e293b; font-size: 18px;">Your Action Plan</h4>
                <p style="margin: 0; color: #64748b; line-height: 1.6;">Personalized Career Launch Kit with templates, guides, and next steps tailored to your dream job.</p>
                <div style="background: #7c3aed; color: white; display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; margin-top: 8px; font-weight: 500;">WEEK 3</div>
              </div>
            </div>
          </div>
          
          <!-- Pro Tip -->
          <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); padding: 20px; border-radius: 12px; margin: 30px 0; border-left: 4px solid #f59e0b;">
            <div style="display: flex; align-items: flex-start;">
              <span style="font-size: 24px; margin-right: 15px;">💡</span>
              <div>
                <h4 style="margin: 0 0 8px 0; color: #92400e; font-size: 16px;">Pro Tip</h4>
                <p style="margin: 0; color: #92400e; line-height: 1.6;">Check out our new AI Career Assistant on the website for instant answers to your career questions!</p>
              </div>
            </div>
          </div>
          
          <!-- Perks -->
          <div style="background: white; border: 2px solid #0891b2; border-radius: 16px; padding: 30px; margin: 30px 0;">
            <h3 style="color: #0891b2; margin: 0 0 20px 0; font-size: 20px; text-align: center;">🎁 Exclusive Early Access Perks</h3>
            <div style="color: #334155; line-height: 2;">
              <div style="margin-bottom: 10px;">✓ Free Career Launch Kit <span style="color: #059669; font-weight: 600;">(Value: $97)</span></div>
              <div style="margin-bottom: 10px;">✓ First access to our roadmap database</div>
              <div style="margin-bottom: 10px;">✓ Priority career coaching spots</div>
              <div style="margin-bottom: 10px;">✓ Exclusive community of ambitious students</div>
            </div>
          </div>
          
          <!-- CTA -->
          <div style="text-align: center; margin: 40px 0;">
            <h3 style="color: #1e293b; margin: 0 0 10px 0; font-size: 22px;">Ready to turn your degree into your dream career?</h3>
            <div style="background: linear-gradient(135deg, #0891b2 0%, #059669 100%); color: white; padding: 15px 30px; border-radius: 50px; display: inline-block; font-weight: 600; text-decoration: none; margin: 20px 0;">
              Let's go further together 🚀
            </div>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <p style="color: #64748b; margin: 0; line-height: 1.6;">
              Best regards,<br>
              <strong style="color: #334155;">The Pathwise Team</strong>
            </p>
          </div>
          
          <!-- P.S. -->
          <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border-left: 4px solid #94a3b8; margin: 30px 0;">
            <p style="margin: 0; color: #475569; font-style: italic;">
              <strong>P.S.</strong> Reply to this email if you have any urgent career questions - we read every message!
            </p>
          </div>
        </div>
        
        <!-- Footer -->
        <div style="background: #1e293b; padding: 30px; text-align: center;">
          <div style="color: white; font-size: 24px; font-weight: bold; margin-bottom: 10px;">Pathwise</div>
          <p style="color: #94a3b8; margin: 0; font-size: 14px; line-height: 1.6;">
            Your degree got you this far — let's go further.<br>
            © 2025 Pathwise. All rights reserved.
          </p>
        </div>
      </div>
    </body>
    </html>
    `
  };

  return await sendEmail(emailContent);
}

export async function sendAdminNotification(signup: { name: string; email: string; major: string; dreamJob: string }): Promise<boolean> {
  const adminEmail = 'admin@pathwise.com'; // Replace with your admin email
  
  const emailContent = {
    to: adminEmail,
    from: 'noreply@pathwise.com',
    subject: 'New Early Access Signup - Pathwise',
    text: `New early access signup:

Name: ${signup.name}
Email: ${signup.email}
Major: ${signup.major}
Dream Job: ${signup.dreamJob}

Check the admin dashboard for more details.`,
    html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8fafc; padding: 20px;">
      <div style="background: white; padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0;">
        <h2 style="color: #0891b2; margin-top: 0;">New Early Access Signup</h2>
        
        <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0; color: #334155;"><strong>Name:</strong> ${signup.name}</p>
          <p style="margin: 5px 0; color: #334155;"><strong>Email:</strong> ${signup.email}</p>
          <p style="margin: 5px 0; color: #334155;"><strong>Major:</strong> ${signup.major}</p>
          <p style="margin: 5px 0; color: #334155;"><strong>Dream Job:</strong> ${signup.dreamJob}</p>
        </div>
        
        <p style="color: #64748b;">Check the admin dashboard for more details.</p>
      </div>
    </div>
    `
  };

  return await sendEmail(emailContent);
}