import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEarlyAccessSchema } from "@shared/schema";
import { z } from "zod";
import { sendWelcomeEmail, sendAdminNotification } from "./email";

export async function registerRoutes(app: Express): Promise<Server> {
  // Early access signup endpoint
  app.post("/api/early-access", async (req, res) => {
    try {
      const validatedData = insertEarlyAccessSchema.parse(req.body);
      
      // Check if email already exists
      const existingSignup = await storage.getEarlyAccessSignupByEmail(validatedData.email);
      if (existingSignup) {
        return res.status(400).json({ 
          message: "Email already registered for early access",
          code: "EMAIL_EXISTS"
        });
      }

      const signup = await storage.createEarlyAccessSignup(validatedData);
      
      // Send welcome email to user (async, don't wait)
      sendWelcomeEmail(signup.email, signup.name).catch(error => {
        console.error("Failed to send welcome email:", error);
      });
      
      // Send admin notification (async, don't wait)
      sendAdminNotification({
        name: signup.name,
        email: signup.email,
        major: signup.major,
        dreamJob: signup.dreamJob
      }).catch(error => {
        console.error("Failed to send admin notification:", error);
      });
      
      res.status(201).json({ 
        message: "Successfully signed up for early access!",
        id: signup.id 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid input data",
          errors: error.errors 
        });
      }
      
      console.error("Early access signup error:", error);
      res.status(500).json({ 
        message: "Internal server error" 
      });
    }
  });

  // Get all early access signups (admin endpoint)
  app.get("/api/early-access", async (req, res) => {
    try {
      const signups = await storage.getEarlyAccessSignups();
      // Sort by creation date, newest first
      const sortedSignups = signups.sort((a, b) => {
        if (!a.createdAt || !b.createdAt) return 0;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
      res.json(sortedSignups);
    } catch (error) {
      console.error("Get signups error:", error);
      res.status(500).json({ 
        message: "Internal server error" 
      });
    }
  });

  // Get early access stats
  app.get("/api/early-access/stats", async (req, res) => {
    try {
      const signups = await storage.getEarlyAccessSignups();
      res.json({ 
        totalSignups: signups.length,
        recentSignups: signups.filter(s => {
          const dayAgo = new Date();
          dayAgo.setDate(dayAgo.getDate() - 1);
          return s.createdAt && s.createdAt > dayAgo;
        }).length
      });
    } catch (error) {
      console.error("Stats error:", error);
      res.status(500).json({ 
        message: "Internal server error" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
