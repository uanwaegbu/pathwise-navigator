#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Create project structure
const createProject = () => {
  const projectName = 'pathwise-career-platform';
  
  // Create main directory
  if (!fs.existsSync(projectName)) {
    fs.mkdirSync(projectName);
  }
  
  // Create subdirectories
  const dirs = [
    'client/src/components/ui',
    'client/src/pages',
    'client/src/hooks', 
    'client/src/lib',
    'server',
    'shared'
  ];
  
  dirs.forEach(dir => {
    fs.mkdirSync(path.join(projectName, dir), { recursive: true });
  });
  
  console.log(`Created project directory: ${projectName}`);
  console.log('Project structure ready for GitHub!');
  console.log('\nNext steps:');
  console.log('1. Copy all the files from this Replit to your local project folder');
  console.log('2. Run: npm install');
  console.log('3. Set up your .env file with database credentials');
  console.log('4. Run: npm run db:push');
  console.log('5. Run: npm run dev');
};

createProject();